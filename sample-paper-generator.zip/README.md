# Sample Paper Generator

A standalone Next.js app that turns supplied study material into a question paper and a separate answer key, with a configurable ICSE Class IX History 80-mark template inspired by the sample/pattern PDFs supplied by the user.

## Features
- Paste study material or upload a `.txt` file.
- Generate a structured question paper with the OpenAI API.
- Fixed template: Part I (30 marks), Part II (50 marks), section instructions and marks.
- Validate the generated question counts and mark totals before PDF export.
- Download a print-friendly PDF question paper and a separate answer key PDF.
- API key stays on the server.

## Run locally
1. Install Node.js 18.17+.
2. Copy `.env.example` to `.env.local`.
3. Add your OpenAI API key to `.env.local`.
4. Run `npm install`, then `npm run dev`.
5. Open http://localhost:3000.

## Deploy to GitHub + Vercel
1. Create a GitHub repository named `sample-paper-generator`.
2. Upload/push all files in this folder to the repository.
3. Import the repository into Vercel.
4. In Vercel Project Settings → Environment Variables, add `OPENAI_API_KEY`.
5. Deploy.

## Notes
- Generated questions depend on the supplied source material. Review the paper before using it for a real examination.
- The 80-mark template reflects the user-provided pattern as interpreted in the conversation. Review the blueprint in `lib/template.ts` and adjust if your original PDF differs.
- PDF output is clean, print-friendly and structured to resemble the sample; exact reproduction of the original school's typography/layout may require further visual calibration.
