 "use client";

import { useState } from "react";

type Paper = {
  title: string;
  subject: string;
  grade: string;
  duration: string;
  totalMarks: number;
  instructions: string[];
  parts: Array<{
    title: string;
    marks: number;
    instructions: string[];
    questions: Array<{
      number: string;
      text: string;
      marks: number;
      type?: string;
      options?: string[];
      subquestions?: Array<{ label: string; text: string; marks: number }>;
    }>;
  }>;
};
type Key = { answers: Array<{ number: string; answer: string; explanation?: string }> };

export default function Home() {
  const [material, setMaterial] = useState("");
  const [subject, setSubject] = useState("History");
  const [grade, setGrade] = useState("IX");
  const [school, setSchool] = useState("");
  const [difficulty, setDifficulty] = useState("Mixed");
  const [extraTopics, setExtraTopics] = useState("");
  const [paper, setPaper] = useState<Paper | null>(null);
  const [answerKey, setAnswerKey] = useState<Key | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [status, setStatus] = useState("");

  async function generate() {
    setError(""); setStatus(""); setPaper(null); setAnswerKey(null);
    if (material.trim().length < 100) {
      setError("Please paste at least a short paragraph of study material (100 characters or more).");
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ material, subject, grade, school, difficulty, extraTopics }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Unable to generate the paper.");
      setPaper(data.paper);
      setAnswerKey(data.answerKey);
      setStatus("Paper generated. Review it before downloading or using it in an examination.");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong.");
    } finally { setBusy(false); }
  }

  async function download(kind: "paper" | "answer-key") {
    if (!paper || !answerKey) return;
    setError("");
    try {
      const res = await fetch("/api/pdf", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kind, paper, answerKey, school }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || "PDF creation failed.");
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = kind === "paper" ? "sample-question-paper.pdf" : "sample-paper-answer-key.pdf";
      document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
    } catch (e) { setError(e instanceof Error ? e.message : "Download failed."); }
  }

  return (
    <main className="shell">
      <header className="topbar">
        <div className="brandMark">SP</div>
        <div><div className="eyebrow">STUDY TOOLS</div><div className="brandName">Sample Paper Generator</div></div>
        <div className="topTag">80-MARK TEMPLATE</div>
      </header>

      <section className="hero">
        <div className="heroCopy">
          <div className="eyebrow">BUILD A PRACTICE PAPER</div>
          <h1>Your material.<br /><em>A structured paper.</em></h1>
          <p>Paste notes or a chapter and generate a print-ready question paper with a separate answer key.</p>
          <div className="heroMeta"><span>● Fixed sections</span><span>● Mark validation</span><span>● PDF download</span></div>
        </div>
        <div className="paperIllustration" aria-hidden="true">
          <div className="paperBack"></div><div className="paperFront">
            <div className="mockSchool">SAMPLE EXAMINATION</div><div className="mockLine wide"></div><div className="mockLine"></div>
            <div className="mockRule"></div><div className="mockSection">PART I</div>
            {[1,2,3,4,5].map(n => <div className="mockQuestion" key={n}><b>{n}.</b><span><i></i><i></i></span></div>)}
            <div className="mockSection">PART II</div>
            {[6,7,8].map(n => <div className="mockQuestion" key={n}><b>{n}.</b><span><i></i><i></i></span></div>)}
          </div>
        </div>
      </section>

      <div className="contentGrid">
        <section className="panel inputPanel">
          <div className="sectionHead"><div><div className="eyebrow">01 / INPUT</div><h2>Set up your paper</h2></div><span className="stepNumber">01</span></div>
          <label className="fieldLabel" htmlFor="material">Study material <span className="required">Required</span></label>
          <textarea id="material" value={material} onChange={e => setMaterial(e.target.value)} placeholder="Paste textbook content, notes, or a chapter here. Questions will be based on this material…" />
          <div className="textareaFoot"><span>Minimum 100 characters</span><span>{material.length.toLocaleString()} characters</span></div>
          <label className="uploadBox">
            <span className="uploadIcon">↑</span><span><b>Upload a text file</b><small>.txt format</small></span>
            <input type="file" accept=".txt,text/plain" onChange={async e => {
              const file = e.target.files?.[0]; if (file) setMaterial(await file.text());
            }} />
          </label>
          <div className="formRow">
            <div><label className="fieldLabel" htmlFor="subject">Subject</label><input id="subject" value={subject} onChange={e => setSubject(e.target.value)} /></div>
            <div><label className="fieldLabel" htmlFor="grade">Grade / class</label><input id="grade" value={grade} onChange={e => setGrade(e.target.value)} /></div>
          </div>
          <label className="fieldLabel" htmlFor="school">School / institution name <span className="optional">Optional</span></label>
          <input id="school" value={school} onChange={e => setSchool(e.target.value)} placeholder="Enter school name for the paper heading" />
          <label className="fieldLabel" htmlFor="difficulty">Difficulty</label>
          <select id="difficulty" value={difficulty} onChange={e => setDifficulty(e.target.value)}>
            <option>Mixed</option><option>Easy</option><option>Moderate</option><option>Difficult</option>
          </select>
          <label className="fieldLabel" htmlFor="topics">Topics to emphasise <span className="optional">Optional</span></label>
          <input id="topics" value={extraTopics} onChange={e => setExtraTopics(e.target.value)} placeholder="e.g. causes, key dates, comparisons" />
          <div className="templateInfo">
            <div className="templateIcon">▤</div><div><b>ICSE Grade IX · History</b><p>80 marks · 2 hours · Part I: 30 marks · Part II: 50 marks</p></div><span className="locked">FIXED</span>
          </div>
          <button className="primaryButton" onClick={generate} disabled={busy}>{busy ? <><span className="spinner"></span> Generating paper…</> : <>Generate sample paper <span>↗</span></>}</button>
          <p className="privacyNote">Your material is sent to the configured AI service to generate questions. Add your API key on the server; never in browser code.</p>
          {error && <div className="alert error">{error}</div>}
          {status && <div className="alert success">{status}</div>}
        </section>

        <section className="panel previewPanel">
          <div className="sectionHead"><div><div className="eyebrow">02 / OUTPUT</div><h2>Paper preview</h2></div><span className="stepNumber">02</span></div>
          {!paper ? <div className="emptyPreview">
            <div className="emptyDoc"><div className="emptyDocTop"></div><div className="emptyDocTitle"></div><div className="emptyDocLine"></div><div className="emptyDocLine short"></div><div className="emptyDocRule"></div><div className="emptyDocSection"></div>{[1,2,3,4].map(n => <div className="emptyDocQ" key={n}><span></span><i></i></div>)}</div>
            <h3>Your paper will appear here</h3><p>Add your study material and generate a paper. Review the questions, then download a print-ready PDF.</p>
            <div className="previewChecklist"><span>✓</span> Structured sections & marks</div><div className="previewChecklist"><span>✓</span> Separate answer key</div><div className="previewChecklist"><span>✓</span> Print-ready PDF</div>
          </div> : <div className="previewContent">
            <div className="paperPreviewHeader">{school && <b>{school.toUpperCase()}</b>}<h3>{paper.title}</h3><p>{paper.subject} · Grade {paper.grade}</p><div className="paperStats"><span>{paper.duration}</span><span>{paper.totalMarks} marks</span></div></div>
            {paper.instructions.map((x,i) => <p className="previewInstruction" key={i}>{x}</p>)}
            {paper.parts.map(part => <div className="previewPart" key={part.title}><h4>{part.title} <span>{part.marks} marks</span></h4>{part.instructions.map((x,i)=><p key={i}>{x}</p>)}{part.questions.map(q=><div className="previewQuestion" key={q.number}><b>{q.number}. {q.text}</b><span>({q.marks} marks)</span>{q.options?.map((o,i)=><small key={i}>{String.fromCharCode(97+i)}) {o}</small>)}{q.subquestions?.map(s=><small key={s.label}>{s.label} {s.text} ({s.marks})</small>)}</div>)}</div>)}
            <div className="downloadActions"><button className="primaryButton" onClick={() => download("paper")}>Download question paper PDF ↓</button><button className="secondaryButton" onClick={() => download("answer-key")}>Download answer key PDF ↓</button></div>
            <p className="reviewNote">Please review all generated questions and answers before using this paper for an examination.</p>
          </div>}
        </section>
      </div>
      <footer><span>Sample Paper Generator</span><span>Generate thoughtfully. Review carefully.</span></footer>
    </main>
  );
}
