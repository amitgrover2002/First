import { NextResponse } from "next/server";
import PDFDocument from "pdfkit";

export const runtime = "nodejs";

export async function POST(req: Request) {
  try {
    const { kind, paper, answerKey, school } = await req.json();
    if (!paper || !answerKey || !["paper", "answer-key"].includes(kind)) {
      return NextResponse.json({ error: "Missing paper data." }, { status: 400 });
    }
    const doc = new PDFDocument({ size: "A4", margins: { top: 52, bottom: 52, left: 58, right: 58 }, bufferPages: true });
    const chunks: Buffer[] = [];
    doc.on("data", (chunk: Buffer) => chunks.push(chunk));
    const finished = new Promise<Buffer>((resolve, reject) => {
      doc.on("end", () => resolve(Buffer.concat(chunks)));
      doc.on("error", reject);
    });

    const ink = "#202820";
    const muted = "#5c665f";
    const rule = "#aebbb1";
    const center = (text: string, size = 11, bold = false) => {
      doc.font(bold ? "Helvetica-Bold" : "Helvetica").fontSize(size).fillColor(ink).text(text, { align: "center" });
    };
    const heading = (text: string) => {
      doc.moveDown(0.5).font("Helvetica-Bold").fontSize(12).fillColor(ink).text(text, { underline: true });
      doc.moveDown(0.2);
    };
    const para = (text: string, size = 10) => {
      doc.font("Helvetica").fontSize(size).fillColor(ink).text(text, { lineGap: 2, paragraphGap: 3 });
    };
    const pageRule = () => {
      const y = doc.y + 5;
      doc.strokeColor(rule).lineWidth(0.6).moveTo(doc.page.margins.left, y).lineTo(doc.page.width - doc.page.margins.right, y).stroke();
      doc.moveDown(0.7);
    };

    if (kind === "paper") {
      if (school) center(String(school).toUpperCase(), 12, true);
      center(paper.title || "Summative Assessment I", 14, true);
      center(`Subject: ${paper.subject}     Grade: ${paper.grade}`, 10, true);
      doc.moveDown(0.3);
      doc.font("Helvetica-Bold").fontSize(10).fillColor(ink).text(`Time: ${paper.duration}`, { continued: true });
      doc.text(`                         Maximum Marks: ${paper.totalMarks}`);
      pageRule();
      paper.instructions?.forEach((s: string, i: number) => para(`${i + 1}. ${s}`, 9));
      for (const part of paper.parts) {
        heading(part.title);
        part.instructions?.forEach((s: string) => para(s, 9));
        for (const q of part.questions) {
          if (q.number === "1" && q.subquestions?.length) {
            para("Question 1. Choose the correct answer for each of the following:", 10);
            q.subquestions.forEach((s: any, idx: number) => {
              doc.moveDown(0.3);
              para(`${idx + 1}. ${s.text} [1]`);
              if (s.options?.length) s.options.forEach((o: string, oi: number) => para(`   (${String.fromCharCode(97 + oi)}) ${o}`, 9));
            });
          } else if (q.number === "2" && q.subquestions?.length) {
            para("Question 2. Answer the following questions briefly:", 10);
            q.subquestions.forEach((s: any, idx: number) => {
              doc.moveDown(0.35);
              para(`${idx + 1}. ${s.text} [${s.marks}]`);
            });
          } else {
            doc.moveDown(0.35);
            para(`${q.number}. ${q.text} [${q.marks} marks]`, 10);
            q.subquestions?.forEach((s: any) => {
              doc.moveDown(0.2);
              para(`   ${s.label} ${s.text} [${s.marks}]`, 10);
            });
            if (q.type === "picture-study") {
              doc.moveDown(0.3);
              doc.rect(doc.x + 14, doc.y, 210, 64).strokeColor(rule).lineWidth(0.7).stroke();
              doc.font("Helvetica-Oblique").fontSize(8).fillColor(muted).text("[Insert picture / illustration here]", doc.x + 18, doc.y + 25, { width: 202, align: "center" });
              doc.moveDown(4.7);
            }
          }
        }
      }
    } else {
      center("ANSWER KEY", 15, true);
      center(paper.title || "Summative Assessment I", 11, true);
      center(`${paper.subject} · Grade ${paper.grade}`, 10);
      pageRule();
      for (const item of answerKey.answers) {
        doc.moveDown(0.4);
        doc.font("Helvetica-Bold").fontSize(10).fillColor(ink).text(`${item.number}. `, { continued: true });
        doc.font("Helvetica").text(item.answer);
        if (item.explanation) para(`Explanation: ${item.explanation}`, 9);
      }
    }

    const range = doc.bufferedPageRange();
    for (let i = 0; i < range.count; i++) {
      doc.switchToPage(i);
      doc.font("Helvetica").fontSize(8).fillColor(muted).text(
        `Sample Paper Generator  •  Page ${i + 1} of ${range.count}`,
        58,
        doc.page.height - 35,
        { width: doc.page.width - 116, align: "center" }
      );
    }
    doc.end();
    const buffer = await finished;
    return new Response(new Uint8Array(buffer), {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${kind === "paper" ? "sample-question-paper.pdf" : "sample-paper-answer-key.pdf"}"`,
        "Cache-Control": "no-store"
      }
    });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "Could not create PDF." }, { status: 500 });
  }
}
