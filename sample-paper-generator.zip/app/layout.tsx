import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Sample Paper Generator",
  description: "Generate structured sample question papers from study material.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
