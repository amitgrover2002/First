export const HISTORY_IX_TEMPLATE = {
  title: "Summative Assessment I",
  subject: "History",
  grade: "IX",
  duration: "2 hours",
  totalMarks: 80,
  instructions: [
    "Answers to this paper must be written on the answer sheet provided separately.",
    "You will not be allowed to write during the first 15 minutes. This time is to be spent reading the question paper.",
    "Attempt all questions in Part I. Attempt the required number of questions in Part II as stated in each section.",
    "The intended marks for questions or parts of questions are given in brackets."
  ],
  partI: {
    title: "PART I (30 MARKS)",
    marks: 30,
    question1Marks: 16,
    question2Marks: 14,
    question1Blueprint: [
      "5 marks: application-based MCQs using case studies/cartoons",
      "2 marks: assertion/reason MCQs",
      "4 marks: recall MCQs",
      "5 marks: understanding MCQs"
    ],
    question2Blueprint: "7 short-answer questions, 2 marks each"
  },
  partII: {
    title: "PART II (50 MARKS)",
    marks: 50,
    sectionA: {
      title: "SECTION A",
      questionNumbers: [3, 4, 5],
      marksEach: 10,
      attempt: "Attempt any two questions",
      subquestionMarks: [3, 3, 4]
    },
    sectionB: {
      title: "SECTION B",
      questionNumbers: [6, 7, 8, 9, 10],
      marksEach: 10,
      attempt: "Attempt any three questions",
      subquestionMarks: [3, 3, 4],
      requirement: "At least one picture-study question"
    }
  }
} as const;
